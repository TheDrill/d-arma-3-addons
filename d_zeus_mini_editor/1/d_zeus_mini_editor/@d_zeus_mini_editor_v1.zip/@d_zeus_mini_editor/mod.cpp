name = "d Zeus mini editor v1";
hideName = "false";
description = "An addon and a DLL extension to save objects (created and moved in Zeus) to SQM file. Works only for primary Arma 3 profile. Use at your own risk!";
overview = "An addon and a DLL extension to save objects (created and moved in Zeus) to SQM file. Use at your own risk! Works only for primary Arma 3 profile. All functions of the addon could be accessed through actions menu in-game. Look Readme.txt in @d_zeus_mini_editor directory for more details."