An addon and a DLL extension to save objects (created and moved in Zeus) to SQM file. 

Use at your own risk! 

Works only for primary Arma 3 profile. 

All functions of the addon could be accessed through actions menu in-game. Basically, the one needs to start the mission being edited (not in pbo form), run 'ZTE begin' action, go to zeus interface, add all needed objects and then run 'ZTE finalize' action to save the changes to the SQM file. The one might reload then the mission --- and added objects before would also be editable in Zeus. Actually, any object of appropriate type with some name is automatically added to zeus. Addon support only non-ai/non-player objects with no side. It automatically adds name of form '__dzte_*' to all objects which was created in the Zeus to be able to edit them later.